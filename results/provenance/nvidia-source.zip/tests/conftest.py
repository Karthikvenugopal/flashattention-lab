import json

import pytest
import torch

from attention_lab.devices import environment, native_metal_probe


@pytest.fixture(scope="session", autouse=True)
def record_execution_environment(record_testsuite_property):
    # Keep hardware visibility tied to the process that actually ran the tests.
    record_testsuite_property("environment", json.dumps(environment()))
    record_testsuite_property("native_metal", json.dumps(native_metal_probe()))


@pytest.fixture(scope="session", autouse=True)
def single_cpu_thread():
    # Tiny matrix tests otherwise mostly measure thread-pool overhead.
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)
